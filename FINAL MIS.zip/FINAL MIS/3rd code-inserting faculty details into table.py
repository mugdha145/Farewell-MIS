import csv
import mysql.connector

# Connect to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Deva@2002",
    database="3MBA"
)
cursor = conn.cursor()
cursor.execute("USE 3MBA")
# Read data from CSV file
csv_filename = "Faculty details.csv"
with open(csv_filename, 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    next(csv_reader)  # Skip header row
    for row in csv_reader:
        sr_no = row[0]
        faculty_name = row[1]
        designation = row[2]
        amount = row[3]
        # Insert data into MySQL table
        query = "INSERT INTO faculty_details(SR_NO, Faculty_Name, Designation, Amount) VALUES (%s, %s, %s, %s)"
        values = (sr_no, faculty_name, designation, amount)
        cursor.execute(query, values)
        
# Commit changes and close connection
conn.commit()
cursor.close()
conn.close()

print("Data has been inserted into the Faculty_details table.")
