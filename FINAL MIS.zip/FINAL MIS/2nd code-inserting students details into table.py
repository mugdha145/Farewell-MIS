import csv
import mysql.connector

# Connect to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Deva@2002",
    database="3MBA"
)
cursor = conn.cursor()
cursor.execute("USE 3MBA")
# Read data from CSV file
csv_filename = "Student details.csv"
with open(csv_filename, 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    next(csv_reader)  # Skip header row
    for row in csv_reader:
        sr_no = row[0]
        register_no = row[1]
        student_name = row[2]
        amount = row[3]
        section = row[4]
        
        # Insert data into MySQL table
        query = "INSERT INTO student_details(SR_NO, Register_No, Student_Name, Amount, Section) VALUES (%s, %s, %s, %s, %s)"
        values = (sr_no, register_no, student_name, amount, section)
        cursor.execute(query, values)
        
# Commit changes and close connection
conn.commit()
cursor.close()
conn.close()

print("Data has been inserted into the student_details table.")
