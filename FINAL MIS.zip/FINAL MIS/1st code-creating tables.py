import mysql.connector

conn=mysql.connector.connect(
    host="localhost",
    user="root",
    password="Deva@2002",                                                                                           
    database="3MBA"
)

print(conn)
cursor = conn.cursor()
cursor.execute("USE 3MBA")

cursor.execute("CREATE TABLE student_details(sr_no int primary key, register_no int, student_name varchar(255), amount int, section varchar(255))")

cursor.execute("CREATE TABLE faculty_details(sr_no int , faculty_name varchar(255) primary key, designation varchar(255), amount int)")
