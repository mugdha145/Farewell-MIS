import mysql.connector

# To connect to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Deva@2002",
    database="3MBA"
)
cursor = conn.cursor()
cursor.execute("USE 3MBA")

# Menu list to define options available to the user
menu = {
    '1': "Details of students who have contributed",
    '2': "Details of students who have not contributed",
    '3': "Details of faculties who have contributed",
    '4': "Details of faculties who have not contributed",
    '5': "Total contribution from students",
    '6': "Total contributions from staff",
    '7': "Overall contribution",
    '8': "Maximum and Minimum amount contributed",
    '9': "Exit"
}

# Main loop for user interaction
while True:
    # Display the options to the user and prompt to get input from user
    option = input('''
    Please select an option:
    1.Details of students who have contributed
    2.Details of students who have not contributed
    3.Details of faculties who have contributed
    4.Details of faculties who have not contributed
    5.Total contribution from students 
    6.Total contributions from staff
    7.Overall contribution
    8.Maximum and Minimum amount contributed
    9.Exit
    ''')

    # Check if the input option is present in the defined menu list or not
    if option in menu:
        # Execute corresponding actions based on the selected option
        if option == '1':
            print(menu[option])
            # Query database for students who contributed
            cursor.execute("SELECT * FROM student_details WHERE amount=100")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '2':
            print(menu[option])
            # Query database for students who did not contribute
            cursor.execute("SELECT * FROM student_details WHERE amount=0")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '3':
            print(menu [option])
            # Query database for staff who contributed
            cursor.execute("SELECT * FROM faculty_details WHERE amount=500")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '4':
            print(menu[option])
            print("All Faculty contributed")
        elif option == '5':
            print(menu [option])
            # Calculate total contribution from students
            cursor.execute("SELECT SUM(amount) FROM student_details")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '6':
            print(menu[option])
            # Calculate total contributions from staff
            cursor.execute("SELECT SUM(amount) FROM faculty_details")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '7':
            print(menu[option])
            # Calculate overall contribution (sum of amounts from both tables
            cursor.execute("SELECT SUM(amount) AS total_sum FROM (SELECT amount FROM faculty_details UNION ALL SELECT amount FROM student_details) AS combined_table")
            result = cursor.fetchall()
            for x in result:
              print(x)
        elif option == '8':
            print(menu [option])
            print("Every student has contributed Rs.100\nEvery Faculty has contributed Rs.500")
        elif option == '9':
            # Exit the loop if option 9 is selected
            break
    else:
        # Display message for invalid options
        print("Invalid option. Please try again!!")
